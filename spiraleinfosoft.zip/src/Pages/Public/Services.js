import { Typography } from '@mui/material'
import React from 'react'

const Services = () => {
    return (
        <div>
            <Typography>services</Typography>
        </div>
    )
}

export default Services
