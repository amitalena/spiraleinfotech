import React from 'react'
import PublicRoutes from './Routes/PublicRoutes'

const MainRouter = () => {
    return (
        <div>
            <PublicRoutes />
        </div>
    )
}

export default MainRouter
